import { Product } from './product';

export const PRODUCTS: Product[] = [
  { id: 1, name: 'Product1' },
  { id: 2, name: 'Product2' },
  { id: 3, name: 'Product3' },
];